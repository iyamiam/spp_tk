<?php
include 'function/function_rupiah.php';
include 'koneksi.php';
include 'header.php';
?>

<?php
if (isset($_GET['nipd']) && $_GET['nipd'] != "") {
  $nipd = $_GET['nipd'];
  $query = "SELECT siswa.*, angkatan.*, kelompok.*, kelas.* FROM siswa, angkatan, kelompok, kelas WHERE siswa.id_angkatan = angkatan.id_angkatan AND siswa.id_kelompok = kelompok.id_kelompok AND siswa.id_kelas = kelas.id_kelas AND siswa.nipd = '$nipd'";

  $exec = mysqli_query($conn, $query);
  $siswa = mysqli_fetch_assoc($exec);

  if ($siswa) {
    $id_siswa = $siswa['id_siswa'];
    $nipd = $siswa['nipd'];

?>
    <div class="card shadow mb-4">
      <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary">Biodata Siswa</h6>
      </div>
      <div class="card-body">
        <div class="table-responsive">
          <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
            <tr>
              <td>NIPD</td>
              <td><?= $siswa['nipd'] ?></td>
            </tr>
            <tr>
              <td>Nama Siswa</td>
              <td><?= $siswa['nama_siswa'] ?></td>
            </tr>
            <tr>
              <td>Kelas</td>
              <td><?= $siswa['nama_kelas'] ?></td>
            </tr>
            <tr>
              <td>Tahun Ajaran</td>
              <td><?= $siswa['tahun_angkatan'] ?></td>
            </tr>
          </table>
        </div>
      </div>
    </div>

    <div class="card shadow mb-4">
      <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary">Data Pembayaran</h6>
      </div>
      <div class="card-body">
        <div class="table-responsive">
          <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
            <thead>
              <tr>
                <th>No</th>
                <th>Bulan</th>
                <th>Jatuh Tempo</th>
                <th>No Bayar</th>
                <th>Tanggal Bayar</th>
                <th>Jumlah</th>
                <th>Keterangan</th>
                <th>Aksi</th>
              </tr>
            </thead>
            <tbody>
              <?php
              $no = 1;
              $query = "SELECT * FROM pembayaran WHERE id_siswa = '$id_siswa' ORDER BY jatuh_tempo ASC";
              $exec = mysqli_query($conn, $query);
              while ($res = mysqli_fetch_assoc($exec)) {
              ?>
                <tr>
                  <td><?= $no++ ?></td>
                  <td><?= $res['bulan'] ?></td>
                  <td><?= $res['jatuh_tempo'] ?></td>
                  <td><?= $res['no_bayar'] ?></td>
                  <td><?= $res['tgl_bayar'] ?></td>
                  <td><?= format_rupiah($res['jumlah']) ?></td>
                  <td><?= $res['ket'] ?></td>
                  <td>
                    <?php
                    if ($res['no_bayar'] == '') {
                      echo "<a href='proses_transaksi.php?nipd=$nipd&act=bayar&id=$res[id_spp]'></a> ";
                      echo "<a class='btn btn-primary btn-sm' href='proses_transaksi.php?nipd=$nipd&act=bayar&id=$res[id_spp]'>Bayar</a> ";
                    } else {
                      echo "</a>";
                      echo "<a class='btn btn-danger btn-sm' href='proses_transaksi.php?nipd=$nipd&act=batal&id=$res[id_spp]'>Batal</a> ";
                      echo "<a class='btn btn-success btn-sm' href='cetak_slip_pembayaran.php?nipd=$nipd&act=cetak&id=$res[id_spp]' target='_blank'>Cetak</a> ";
                    }
                    ?>
                  </td>
                </tr>
              <?php } ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
<?php
  } else {
    echo "<div class='alert alert-danger'>Data siswa tidak ditemukan.</div>";
  }
}
?>
<?php include 'footer.php'; ?>