<?php

$conn = mysqli_connect('localhost', 'root', '', 'spp_tk');
if (!$conn) {
  throw new Exception("Database gagal terkoneksi", 1);
}
