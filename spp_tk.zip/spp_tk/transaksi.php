<?php
$bulanIndo = [
  '01' => 'Januari',
  '02' => 'Februari',
  '03' => 'Maret',
  '04' => 'April',
  '05' => 'Mei',
  '06' => 'Juni',
  '07' => 'Juli',
  '08' => 'Agustus',
  '09' => 'September',
  '10' => 'Oktober',
  '11' => 'November',
  '12' => 'Desember',
];

$query = "SELECT siswa.*, angkatan.* FROM siswa, angkatan WHERE siswa.id_angkatan = angkatan.id_angkatan ORDER BY siswa.id_siswa";
$exec = mysqli_query($conn, $query);
$res = mysqli_fetch_assoc($exec);
$biaya = $res['biaya_angkatan'];
$id_siswa = $res['id_siswa'];
$awal_tempo = date('Y-m-d');
for ($i = 0; $i < 12; $i++) {
  // tanggal jatuh tempo setiap tanggal 10
  $jatuh_tempo = date("Y-m-d", strtotime("+$i month", strtotime($awal_tempo)));

  $bulan = $bulanIndo[date('m', strtotime($jatuh_tempo))] . " " . date('Y', strtotime($jatuh_tempo));

  // simpan data
  $add = mysqli_query($conn, "INSERT INTO pembayaran (id_siswa, jatuh_tempo, bulan, jumlah) VALUES ('$id_siswa','$jatuh_tempo','$bulan','$biaya')");
}
