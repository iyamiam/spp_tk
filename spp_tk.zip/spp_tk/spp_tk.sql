-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 29 Jul 2023 pada 07.55
-- Versi server: 10.4.27-MariaDB
-- Versi PHP: 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `spp_tk`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `angkatan`
--

CREATE TABLE `angkatan` (
  `id_angkatan` int(11) NOT NULL,
  `tahun_angkatan` varchar(50) NOT NULL,
  `biaya` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `angkatan`
--

INSERT INTO `angkatan` (`id_angkatan`, `tahun_angkatan`, `biaya`) VALUES
(8, '2023/2024', '300000');

-- --------------------------------------------------------

--
-- Struktur dari tabel `kelas`
--

CREATE TABLE `kelas` (
  `id_kelas` int(11) NOT NULL,
  `nama_kelas` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `kelas`
--

INSERT INTO `kelas` (`id_kelas`, `nama_kelas`) VALUES
(9, 'A'),
(10, 'B'),
(11, 'C');

-- --------------------------------------------------------

--
-- Struktur dari tabel `kelompok`
--

CREATE TABLE `kelompok` (
  `id_kelompok` int(11) NOT NULL,
  `nama_kelompok` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `kelompok`
--

INSERT INTO `kelompok` (`id_kelompok`, `nama_kelompok`) VALUES
(10, 'Kelompok');

-- --------------------------------------------------------

--
-- Struktur dari tabel `pembayaran`
--

CREATE TABLE `pembayaran` (
  `id_spp` int(11) NOT NULL,
  `id_siswa` int(11) NOT NULL,
  `jatuh_tempo` varchar(50) NOT NULL,
  `bulan` varchar(50) NOT NULL,
  `no_bayar` varchar(50) NOT NULL,
  `tgl_bayar` varchar(50) NOT NULL,
  `jumlah` varchar(50) NOT NULL,
  `ket` varchar(50) DEFAULT NULL,
  `id_petugas` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `pembayaran`
--

INSERT INTO `pembayaran` (`id_spp`, `id_siswa`, `jatuh_tempo`, `bulan`, `no_bayar`, `tgl_bayar`, `jumlah`, `ket`, `id_petugas`) VALUES
(269, 25, '2023-07-10', 'Juli 2023', '034934', '2023-07-12', '300000', 'LUNAS', 2),
(270, 25, '2023-08-10', 'Agustus 2023', '035106', '2023-07-12', '300000', 'LUNAS', 2),
(271, 25, '2023-09-10', 'September 2023', '045235', '2023-07-15', '300000', 'LUNAS', 2),
(272, 25, '2023-10-10', 'Oktober 2023', '050704', '2023-07-15', '300000', 'LUNAS', 2),
(273, 25, '2023-11-10', 'November 2023', '052208', '2023-07-15', '300000', 'LUNAS', 2),
(274, 25, '2023-12-10', 'Desember 2023', '052209', '2023-07-15', '300000', 'LUNAS', 2),
(275, 25, '2024-01-10', 'Januari 2024', '050645', '2023-07-15', '300000', 'LUNAS', 2),
(276, 25, '2024-02-10', 'Februari 2024', '050749', '2023-07-15', '300000', 'LUNAS', 2),
(277, 25, '2024-03-10', 'Maret 2024', '052210', '2023-07-15', '300000', 'LUNAS', 2),
(278, 25, '2024-04-10', 'April 2024', '052211', '2023-07-15', '300000', 'LUNAS', 2),
(279, 25, '2024-05-10', 'Mei 2024', '052212', '2023-07-15', '300000', 'LUNAS', 2),
(280, 25, '2024-06-10', 'Juni 2024', '052213', '2023-07-15', '300000', 'LUNAS', 2),
(281, 26, '2023-07-10', 'Juli 2023', '034948', '2023-07-12', '300000', 'LUNAS', 2),
(282, 26, '2023-08-10', 'Agustus 2023', '051833', '2023-07-15', '300000', 'LUNAS', 2),
(283, 26, '2023-09-10', 'September 2023', '', '', '300000', NULL, 0),
(284, 26, '2023-10-10', 'Oktober 2023', '', '', '300000', NULL, 0),
(285, 26, '2023-11-10', 'November 2023', '', '', '300000', NULL, 0),
(286, 26, '2023-12-10', 'Desember 2023', '', '', '300000', NULL, 0),
(287, 26, '2024-01-10', 'Januari 2024', '', '', '300000', NULL, 0),
(288, 26, '2024-02-10', 'Februari 2024', '', '', '300000', NULL, 0),
(289, 26, '2024-03-10', 'Maret 2024', '', '', '300000', NULL, 0),
(290, 26, '2024-04-10', 'April 2024', '', '', '300000', NULL, 0),
(291, 26, '2024-05-10', 'Mei 2024', '', '', '300000', NULL, 0),
(292, 26, '2024-06-10', 'Juni 2024', '', '', '300000', NULL, 0),
(293, 27, '2023-07-10', 'Juli 2023', '035008', '2023-07-12', '300000', 'LUNAS', 2),
(294, 27, '2023-08-10', 'Agustus 2023', '035141', '2023-07-12', '300000', 'LUNAS', 2),
(295, 27, '2023-09-10', 'September 2023', '', '', '300000', NULL, 0),
(296, 27, '2023-10-10', 'Oktober 2023', '', '', '300000', NULL, 0),
(297, 27, '2023-11-10', 'November 2023', '', '', '300000', NULL, 0),
(298, 27, '2023-12-10', 'Desember 2023', '', '', '300000', NULL, 0),
(299, 27, '2024-01-10', 'Januari 2024', '', '', '300000', NULL, 0),
(300, 27, '2024-02-10', 'Februari 2024', '', '', '300000', NULL, 0),
(301, 27, '2024-03-10', 'Maret 2024', '', '', '300000', NULL, 0),
(302, 27, '2024-04-10', 'April 2024', '', '', '300000', NULL, 0),
(303, 27, '2024-05-10', 'Mei 2024', '', '', '300000', NULL, 0),
(304, 27, '2024-06-10', 'Juni 2024', '', '', '300000', NULL, 0),
(305, 28, '2023-07-10', 'Juli 2023', '', '', '300000', NULL, 0),
(306, 28, '2023-08-10', 'Agustus 2023', '', '', '300000', NULL, 0),
(307, 28, '2023-09-10', 'September 2023', '', '', '300000', NULL, 0),
(308, 28, '2023-10-10', 'Oktober 2023', '', '', '300000', NULL, 0),
(309, 28, '2023-11-10', 'November 2023', '', '', '300000', NULL, 0),
(310, 28, '2023-12-10', 'Desember 2023', '', '', '300000', NULL, 0),
(311, 28, '2024-01-10', 'Januari 2024', '', '', '300000', NULL, 0),
(312, 28, '2024-02-10', 'Februari 2024', '', '', '300000', NULL, 0),
(313, 28, '2024-03-10', 'Maret 2024', '', '', '300000', NULL, 0),
(314, 28, '2024-04-10', 'April 2024', '', '', '300000', NULL, 0),
(315, 28, '2024-05-10', 'Mei 2024', '', '', '300000', NULL, 0),
(316, 28, '2024-06-10', 'Juni 2024', '', '', '300000', NULL, 0);

-- --------------------------------------------------------

--
-- Struktur dari tabel `petugas`
--

CREATE TABLE `petugas` (
  `id_petugas` int(11) NOT NULL,
  `nama_petugas` varchar(50) NOT NULL,
  `user_petugas` varchar(50) NOT NULL,
  `pass_petugas` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `petugas`
--

INSERT INTO `petugas` (`id_petugas`, `nama_petugas`, `user_petugas`, `pass_petugas`) VALUES
(2, 'Abdul Sidiq', 'abdul', 'abdul');

-- --------------------------------------------------------

--
-- Struktur dari tabel `siswa`
--

CREATE TABLE `siswa` (
  `id_siswa` int(11) NOT NULL,
  `nipd` varchar(50) NOT NULL,
  `nama_siswa` varchar(50) NOT NULL,
  `id_angkatan` varchar(50) NOT NULL,
  `id_kelompok` varchar(50) NOT NULL,
  `id_kelas` varchar(50) NOT NULL,
  `alamat` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `siswa`
--

INSERT INTO `siswa` (`id_siswa`, `nipd`, `nama_siswa`, `id_angkatan`, `id_kelompok`, `id_kelas`, `alamat`) VALUES
(25, '101', 'Abdul Rohman', '8', '10', '9', 'Jalan Sayang 20'),
(26, '102', 'Taufiqur Rohman', '8', '10', '9', 'Jalan Flamboyan 10'),
(27, '103', 'Ucup Suhendar', '8', '10', '9', 'Jalan Supaya 10'),
(28, '104', 'Siswanto Wibono', '8', '10', '9', 'Jalan Lombok 100');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `angkatan`
--
ALTER TABLE `angkatan`
  ADD PRIMARY KEY (`id_angkatan`);

--
-- Indeks untuk tabel `kelas`
--
ALTER TABLE `kelas`
  ADD PRIMARY KEY (`id_kelas`);

--
-- Indeks untuk tabel `kelompok`
--
ALTER TABLE `kelompok`
  ADD PRIMARY KEY (`id_kelompok`);

--
-- Indeks untuk tabel `pembayaran`
--
ALTER TABLE `pembayaran`
  ADD PRIMARY KEY (`id_spp`);

--
-- Indeks untuk tabel `petugas`
--
ALTER TABLE `petugas`
  ADD PRIMARY KEY (`id_petugas`);

--
-- Indeks untuk tabel `siswa`
--
ALTER TABLE `siswa`
  ADD PRIMARY KEY (`id_siswa`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `angkatan`
--
ALTER TABLE `angkatan`
  MODIFY `id_angkatan` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT untuk tabel `kelas`
--
ALTER TABLE `kelas`
  MODIFY `id_kelas` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT untuk tabel `kelompok`
--
ALTER TABLE `kelompok`
  MODIFY `id_kelompok` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT untuk tabel `pembayaran`
--
ALTER TABLE `pembayaran`
  MODIFY `id_spp` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=317;

--
-- AUTO_INCREMENT untuk tabel `petugas`
--
ALTER TABLE `petugas`
  MODIFY `id_petugas` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT untuk tabel `siswa`
--
ALTER TABLE `siswa`
  MODIFY `id_siswa` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
