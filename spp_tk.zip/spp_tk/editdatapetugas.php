<?php
include 'function/function_rupiah.php';
include 'header.php';
include 'koneksi.php';

if (isset($_GET['id_petugas'])) {
  $id_petugas = $_GET['id_petugas'];
  $exec = mysqli_query($conn, "DELETE FROM petugas WHERE id_petugas = '$id_petugas'");
  if ($exec) {
    echo "<script>alert('data petugas berhasil dihapus')
      document.location = 'editdatapetugas.php';
      </script>";
  } else {
    echo "<script>alert('data petugas gagal dihapus')
      document.location = 'editdatapetugas.php';
      </script>";
  }
}
?>

<!-- button trigger -->
<button class="btn btn-primary mb-3" data-bs-toggle="modal" data-bs-target="#exampleModal">Tambah Data</button>
<!-- button trigger -->

<!-- DataTales Example -->
<div class="card shadow mb-4">
  <div class="card-header py-3">
    <h6 class="m-0 font-weight-bold text-primary">Data Petugas</h6>
  </div>
  <div class="card-body">
    <div class="table-responsive">
      <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
        <thead>
          <tr>
            <th>No</th>
            <th>Nama Petugas</th>
            <th>User Petugas</th>
            <th>Password Petugas</th>
            <th>Aksi</th>
          </tr>
        </thead>
        <tbody>
          <?php
          $no = 1;
          $query = "SELECT * FROM petugas";
          $exec = mysqli_query($conn, $query);
          while ($res = mysqli_fetch_assoc($exec)) :
          ?>
            <tr>
              <td><?= $no++; ?></td>
              <td><?= $res["nama_petugas"] ?></td>
              <td><?= $res["user_petugas"] ?></td>
              <td><?= $res["pass_petugas"] ?></td>
              <td>
                <a href="editdatapetugas.php?id_petugas=<?= $res["id_petugas"] ?>" class="btn btn-sm btn-danger" onclick="return confirm('Apakah Anda yakin ingin menghapus data?')">Hapus</a>
                <a href="#" class="view_data btn btn-sm btn-warning" data-bs-toggle="modal" data-bs-target="#myModal" id="<?php echo $res['id_petugas']; ?>">Edit</a>
              </td>
            </tr>
          <?php endwhile; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Data Petugas</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">x</button>
      </div>
      <div class="modal-body">
        <form action="" method="POST">
          <input type="text" name="nama_petugas" placeholder="Nama Petugas" class="form-control mb-2">
          <input type="text" name="user_petugas" placeholder="User Petugas" class="form-control mb-2">
          <input type="password" name="pass_petugas" placeholder="Password Petugas" class="form-control mb-2">
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
            <button type="submit" name="simpan" class="btn btn-primary">Simpan</button>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>


<div class="modal fade" id="myModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Edit Data Petugas</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">x</button>
      </div>
      <div class="modal-body" id="datapetugas">

      </div>
    </div>
  </div>
</div>


<?php
if (isset($_POST['simpan'])) {
  $nama_petugas = htmlentities(strip_tags(ucwords($_POST['nama_petugas'])));
  $user_petugas = htmlentities(strip_tags($_POST['user_petugas']));
  $pass_petugas = htmlentities(strip_tags($_POST['pass_petugas']));

  $query = "INSERT INTO petugas (nama_petugas,user_petugas,pass_petugas) VALUES ('$nama_petugas','$user_petugas','$pass_petugas')";

  $exec = mysqli_query($conn, $query);
  if ($exec) {
    echo "<script>alert('data petugas berhasil disimpan')
    document.location = 'editdatapetugas.php';
    </script>";
  } else {
    echo "<script>alert('data petugas gagal disimpan')
    document.location = 'editdatapetugas.php';
    </script>";
  }
}
?>
<?php include 'footer.php'; ?>
<script type="text/javascript">
  $('.view_data').click(function() {
    var id_petugas = $(this).attr('id');
    $.ajax({
      url: 'view.php',
      method: 'post',
      data: {
        id_petugas: id_petugas
      },
      success: function(data) {
        $('#datapetugas').html(data)
        $('#myModal').modal('show');
      }
    })
  })
</script>

<?php
if (isset($_POST['edit'])) {
  $id_petugas = $_POST['id_petugas'];
  $nama_petugas = htmlentities(strip_tags(ucwords($_POST['nama_petugas'])));
  $user_petugas = htmlentities(strip_tags($_POST['user_petugas']));
  $pass_petugas = htmlentities(strip_tags($_POST['pass_petugas']));

  $query = "UPDATE petugas SET nama_petugas = '$nama_petugas', user_petugas = '$user_petugas',pass_petugas = '$pass_petugas' WHERE id_petugas = '$id_petugas'";

  $exec = mysqli_query($conn, $query);
  if ($exec) {
    echo "<script>alert('data petugas berhasil diedit')
    document.location = 'editdatapetugas.php';
    </script>";
  } else {
    echo "<script>alert('data petugas gagal diedit')
    document.location = 'editdatapetugas.php';
    </script>";
  }
}
?>