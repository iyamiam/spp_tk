<?php
session_start();
include 'koneksi.php';

if (isset($_GET['act'])) {
  if ($_GET['act'] == 'bayar') {
    $id_spp = $_GET['id'];
    $tgl_bayar = date('Y-m-d');
    $no_bayar = date("His");
    $id_petugas = $_SESSION['petugas'];

    $byr = mysqli_query($conn, "UPDATE pembayaran SET
          no_bayar = '$no_bayar',
          tgl_bayar = '$tgl_bayar',
          ket = 'LUNAS',
          id_petugas = '$id_petugas'
          WHERE id_spp = '$id_spp'");

    if ($byr) {
      if (isset($_GET['nipd'])) {
        $nipd = $_GET['nipd'];
        header("location:detail_siswa.php?nipd=$nipd");
        exit;
      } else {
        echo "<script>alert('gagal')</script>";
      }
    }
  } else if ($_GET['act'] == 'batal') {
    $id_spp = $_GET['id'];
    $nipd = $_GET['nipd'];

    $batal = mysqli_query($conn, "UPDATE pembayaran SET
      no_bayar = null,
      tgl_bayar = null,
      ket = null,
      id_petugas = null WHERE id_spp = '$id_spp'");
    if ($batal) {
      if (isset($_GET['nipd'])) {
        $nipd = $_GET['nipd'];
        header("location:detail_siswa.php?nipd=$nipd");
        exit;
      }
    }
  }
}
