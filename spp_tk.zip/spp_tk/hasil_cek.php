<?php
include 'function/function_rupiah.php';
include 'koneksi.php';
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Cek Pembayaran SPP Siswa</title>
  <link href="https://cdn.datatables.net/1.10.25/css/jquery.dataTables.min.css" rel="stylesheet">
  <style>
    body {
      font-family: Arial, sans-serif;
      background-color: #f4f4f4;
    }

    .container {
      max-width: 800px;
      margin: 0 auto;
      padding: 20px;
      background-color: #fff;
      box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
    }

    h1 {
      text-align: center;
      margin-bottom: 20px;
    }

    table {
      width: 100%;
      border-collapse: collapse;
    }

    th,
    td {
      padding: 10px;
      text-align: left;
      border-bottom: 1px solid #ddd;
    }

    th {
      background-color: #f2f2f2;
      font-weight: bold;
    }

    .alert {
      margin-bottom: 20px;
      padding: 15px;
      background-color: #f8d7da;
      color: #721c24;
      border: 1px solid #f5c6cb;
      border-radius: 4px;
    }

    /* Gaya untuk tabel yang dirapikan */
    .rapikan-table {
      border-collapse: collapse;
      width: 100%;
    }

    .rapikan-table th,
    .rapikan-table td {
      border: 1px solid #ddd;
      padding: 8px;
    }

    .rapikan-table th {
      background-color: #f2f2f2;
      font-weight: bold;
    }
  </style>
</head>

<body>
  <div class="container">
    <h1>Pembayaran SPP Siswa</h1>
    <?php
    if (isset($_GET['nipd']) && $_GET['nipd'] != "") {
      $nipd = $_GET['nipd'];
      $query = "SELECT siswa.*, angkatan.*, kelompok.*, kelas.* FROM siswa, angkatan, kelompok, kelas WHERE siswa.id_angkatan = angkatan.id_angkatan AND siswa.id_kelompok = kelompok.id_kelompok AND siswa.id_kelas = kelas.id_kelas AND siswa.nipd = '$nipd'";

      $exec = mysqli_query($conn, $query);
      $siswa = mysqli_fetch_assoc($exec);

      if ($siswa) {
        $id_siswa = $siswa['id_siswa'];
        $nipd = $siswa['nipd'];
    ?>
        <div class="card">
          <div class="card-header">
            <h3>Biodata Siswa</h3>
          </div>
          <div class="card-body">
            <table class="rapikan-table">
              <tr>
                <th>NIPD</th>
                <td><?= $siswa['nipd'] ?></td>
              </tr>
              <tr>
                <th>Nama Siswa</th>
                <td><?= $siswa['nama_siswa'] ?></td>
              </tr>
              <tr>
                <th>Kelas</th>
                <td><?= $siswa['nama_kelompok'] ?> - <?= $siswa['nama_kelas'] ?></td>
              </tr>
              <tr>
                <th>Tahun Ajaran</th>
                <td><?= $siswa['tahun_angkatan'] ?></td>
              </tr>
            </table>
          </div>
        </div>

        <div class="card">
          <div class="card-header">
            <h3>Data Pembayaran</h3>
          </div>
          <div class="card-body">
            <table class="rapikan-table">
              <thead>
                <tr>
                  <th>No</th>
                  <th>Bulan</th>
                  <th>Jatuh Tempo</th>
                  <th>No Bayar</th>
                  <th>Tanggal Bayar</th>
                  <th>Jumlah</th>
                  <th>Keterangan</th>
                </tr>
              </thead>
              <tbody>
                <?php
                $no = 1;
                $query = "SELECT * FROM pembayaran WHERE id_siswa = '$id_siswa' ORDER BY jatuh_tempo ASC";
                $exec = mysqli_query($conn, $query);
                while ($res = mysqli_fetch_assoc($exec)) {
                ?>
                  <tr>
                    <td><?= $no++ ?></td>
                    <td><?= $res['bulan'] ?></td>
                    <td><?= $res['jatuh_tempo'] ?></td>
                    <td><?= $res['no_bayar'] ?></td>
                    <td><?= $res['tgl_bayar'] ?></td>
                    <td><?= format_rupiah($res['jumlah']) ?></td>
                    <td><?= $res['ket'] ?></td>
                  </tr>
                <?php } ?>
              </tbody>
            </table>
          </div>
        </div>
    <?php
      } else {
        echo "<div class='alert alert-danger'><p>Data siswa tidak ditemukan.</p></div>";
      }
    }
    ?>
  </div>
</body>

</html>