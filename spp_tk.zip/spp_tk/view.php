<?php
include 'koneksi.php';
if (isset($_POST['id_siswa'])) {
  $id_siswa = $_POST['id_siswa'];
  $query = "SELECT siswa.*, angkatan.*, kelompok.*, kelas.* 
            FROM siswa, angkatan, kelompok, kelas 
            WHERE siswa.id_angkatan = angkatan.id_angkatan 
              AND siswa.id_kelompok = kelompok.id_kelompok 
              AND siswa.id_kelas = kelas.id_kelas 
              AND siswa.id_siswa = $id_siswa";
  $exec = mysqli_query($conn, $query);
  $res = mysqli_fetch_assoc($exec);
?>
  <form action="editdatasiswa.php" method="POST" id="edit-form">
    <input type="hidden" name="id_siswa" value="<?= $res['id_siswa'] ?>">
    <input type="hidden" name="nipd" value="<?= $res['nipd'] ?>">
    <input type="text" class="form-control mb-2" name="nipd" disabled="" value="<?= $res['nipd'] ?>">
    <input type="text" class="form-control mb-2" name="nama_siswa" value="<?= $res['nama_siswa'] ?>">
    <select name="id_angkatan" class="form-control mb-2">
      <option selected disabled>-Pilih Angkatan-</option>
      <?php
      $selected = "";
      $exec = mysqli_query($conn, "SELECT * FROM angkatan ORDER BY id_angkatan");
      while ($angkatan = mysqli_fetch_assoc($exec)) :
        if ($res['id_angkatan'] == $angkatan['id_angkatan']) {
          $selected = 'selected';
        } else {
          $selected = "";
        }
        echo "<option $selected value=" . $angkatan['id_angkatan'] . ">" . $angkatan['tahun_angkatan'] . "</option>";
      endwhile;
      ?>
    </select>
    <select name="id_kelas" class="form-control mb-2">
      <option selected disabled>-Pilih Kelas-</option>
      <?php
      $exec = mysqli_query($conn, "SELECT * FROM kelas ORDER BY id_kelas");
      while ($kelas = mysqli_fetch_assoc($exec)) :
        if ($res['id_kelas'] == $kelas['id_kelas']) {
          $selected = 'selected';
        } else {
          $selected = "";
        }
        echo "<option $selected value=" . $kelas['id_kelas'] . ">" . $kelas['nama_kelas'] . "</option>";
      endwhile;
      ?>
    </select>
    <select name="id_kelompok" class="form-control ">
      <option selected disabled>-Pilih Kelompok-</option>
      <?php
      $exec = mysqli_query($conn, "SELECT * FROM kelompok ORDER BY id_kelompok");
      while ($kelompok = mysqli_fetch_assoc($exec)) :
        if ($res['id_kelompok'] == $kelompok['id_kelompok']) {
          $selected = 'selected';
        } else {
          $selected = "";
        }
        echo "<option $selected value=" . $kelompok['id_kelompok'] . ">" . $kelompok['nama_kelompok'] . "</option>";
      endwhile;
      ?>
    </select>
    <textarea name="alamat" class="form-control mt-2" placeholder="Alamat Siswa"><?= $res['alamat'] ?></textarea>
    <div class="modal-footer">
      <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
      <button type="submit" name="edit" class="btn btn-primary">Edit</button>
    </div>
  </form>
<?php } ?>
<?php

if (isset($_POST['id_kelas'])) {
  $id_kelas = $_POST['id_kelas'];
  $exec = mysqli_query($conn, "SELECT * FROM kelas WHERE id_kelas = '$id_kelas'");
  $res = mysqli_fetch_assoc($exec);
?>
  <form action="editdatakelas.php" method="POST" id="edit-form">
    <input type="hidden" name="id_kelas" value="<?= $res['id_kelas'] ?>">
    <input type="text" name="nama_kelas" class="form-control" value="<?= $res['nama_kelas'] ?>">
    <div class="modal-footer">
      <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
      <button type="submit" name="edit" class="btn btn-primary">Edit</button>
    </div>
  </form>

<?php }
if (isset($_POST['id_kelompok'])) {
  $id_kelompok = $_POST['id_kelompok'];
  $exec = mysqli_query($conn, "SELECT * FROM kelompok WHERE id_kelompok = '$id_kelompok'");
  $res = mysqli_fetch_assoc($exec);
?>
  <form action="editdatakelompok.php" method="POST" id="edit-form">
    <input type="hidden" name="id_kelompok" value="<?= $res['id_kelompok'] ?>">
    <input type="text" name="nama_kelompok" class="form-control" value="<?= $res['nama_kelompok'] ?>">
    <div class="modal-footer">
      <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
      <button type="submit" name="edit" class="btn btn-primary">Edit</button>
    </div>
  </form>

<?php }
if (isset($_POST['id_angkatan'])) {
  $id_angkatan = $_POST['id_angkatan'];
  $exec = mysqli_query($conn, "SELECT * FROM angkatan WHERE id_angkatan = '$id_angkatan'");
  $res = mysqli_fetch_assoc($exec);
?>
  <form action="editdataangkatan.php" method="POST" id="edit-form">
    <input type="hidden" name="id_angkatan" value="<?= $res['id_angkatan'] ?>">
    <input type="text" name="tahun_angkatan" class="form-control" value="<?= $res['tahun_angkatan'] ?>">
    <input type="text" name="biaya" class="form-control" value="<?= $res['biaya'] ?>">
    <div class="modal-footer">
      <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
      <button type="submit" name="edit" class="btn btn-primary">Edit</button>
    </div>
  </form>

<?php }
if (isset($_POST['id_petugas'])) {
  $id_petugas = $_POST['id_petugas'];
  $exec = mysqli_query($conn, "SELECT * FROM petugas WHERE id_petugas = '$id_petugas'");
  $res = mysqli_fetch_assoc($exec);
?>
  <form action="editdatapetugas.php" method="POST" id="edit-form">
    <input type="hidden" name="id_petugas" value="<?= $res['id_petugas'] ?>">
    <input type="text" name="nama_petugas" class="form-control" value="<?= $res['nama_petugas'] ?>">
    <input type="text" name="user_petugas" class="form-control" value="<?= $res['user_petugas'] ?>">
    <input type="password" name="pass_petugas" class="form-control" value="<?= $res['pass_petugas'] ?>">
    <div class="modal-footer">
      <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
      <button type="submit" name="edit" class="btn btn-primary">Edit</button>
    </div>
  </form>

<?php }
?>