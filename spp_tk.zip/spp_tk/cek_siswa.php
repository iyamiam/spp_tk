<?php
if (isset($_SESSION['siswa'])) {
  header('location:index.php');
  exit();
}
include 'koneksi.php';
if (isset($_POST['cek'])) {
  $nipd = htmlentities(strip_tags($_POST['nipd']));

  $query = "SELECT * FROM siswa WHERE nipd = '$nipd'";
  $exec = mysqli_query($conn, $query);

  if (mysqli_num_rows($exec) != 0) {
    $res = mysqli_fetch_assoc($exec);
    $_SESSION['siswa'] = $res['id_siswa'];
    $_SESSION['nipd'] = $res['nipd'];
    header("location: hasil_cek.php?nipd=$nipd");
    exit();
  } else {
    echo "<script>alert('NIPD yang Anda masukkan tidak tersedia');
      window.location = 'cek_siswa.php';
      </script>";
    exit();
  }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>Aplikasi Pencatatan SPP TK Pertiwi 3</title>

  <!-- Custom fonts for this template-->
  <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
  <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">

  <!-- Custom styles for this template-->
  <link href="css/sb-admin-2.min.css" rel="stylesheet">

</head>

<body class="container-fluid bg-gradient-primary">

  <div class="container py-5">

    <div class="row justify-content-center">
      <div class="col-lg-6">
        <div class="card o-hidden border-0 shadow-lg">
          <div class="card-body p-0">
            <div class="row">
              <div class="col-lg-12">
                <div class="p-5">
                  <div class="text-center">
                    <img src="img/tk.png" height="150px" alt="">
                    <h2 class="mt-3">Cek Pembayaran SPP</h2>
                    <h4 class="text-primary">Siswa TK Pertiwi 3</h4>
                  </div>
                  <form class="user mt-4" method="POST" action="" target="_blank" id="cekForm">
                    <div class="form-group">
                      <input type="text" autocomplete="off" required name="nipd" class="form-control form-control-user" id="exampleInputEmail" aria-describedby="emailHelp" placeholder="Masukkan NIPD Siswa...">
                    </div>
                    <button type="submit" class="btn btn-primary btn-user btn-block" name="cek" target="_blank">Cek</button>
                  </form>
                  <hr>
                  <div class="text-center">
                    <a href="loginauth.php" class="text-primary">Login Sebagai Admin</a>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- Bootstrap core JavaScript-->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <!-- Core plugin JavaScript-->
  <script src="vendor/jquery-easing/jquery.easing.min.js"></script>
  <!-- Custom scripts for all pages-->
  <script src="js/sb-admin-2.min.js"></script>
</body>

</html>