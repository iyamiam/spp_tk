<?php
include 'function/function_rupiah.php';
include 'function/function_tgl_indo.php';
session_start();
if (isset($_SESSION['petugas'])) {
  include 'koneksi.php';
  $awal = $_GET['awal'];
  $akhir = $_GET['akhir'];
?>
  <!DOCTYPE html>
  <html>

  <head>
    <title>Laporan Pembayaran</title>

    <style>
      body {
        font-family: arial;
      }

      table {
        border-collapse: collapse;
      }
    </style>
  </head>

  <body onload="window.print();">
    <h3 align="center" style="padding-bottom: 1px;">TK PERTIWI 3</h3>
    <p align="center" style="font-size: 12px;">Jalan Sawo Endah No. 31, Komplek Perumahan Pemda, Jl. Ciwastra Komp. Pemda Sawo Endah,
      <br>Margasari, Kec. Buahbatu, Kota Bandung, Jawa Barat 40286
    </p>
    <h3>LAPORAN PEMBAYARAN SPP</h3>
    <p>Tanggal <?= tgl_indo($awal) . " Sampai " . tgl_indo($akhir) ?></p>
    <table border="1" cellspacing="0" cellpadding="4" width="100%">
      <tr>
        <th>NO</th>
        <th>NIPD</th>
        <th>NAMA SISWA</th>
        <th>NO BAYAR</th>
        <th>PEMBAYARAN BULAN</th>
        <th>JUMLAH</th>
        <th>KET</th>
      </tr>
      <?php
      $spp = mysqli_query($conn, "SELECT siswa.*, pembayaran.*, petugas.nama_petugas
      FROM siswa
      JOIN pembayaran ON pembayaran.id_siswa = siswa.id_siswa
      JOIN petugas ON pembayaran.id_petugas = petugas.id_petugas
      WHERE tgl_bayar BETWEEN '$awal' AND '$akhir'");
      $i = 1;
      $total = 0;
      while ($dta = mysqli_fetch_assoc($spp)) :
        $sw = $dta; // Memperoleh data petugas pada setiap iterasi
      ?>
        <tr>
          <td align="center"><?= $i ?></td>
          <td align="center"><?= $dta['nipd'] ?></td>
          <td align="center"><?= $dta['nama_siswa'] ?></td>
          <td align="center"><?= $dta['no_bayar'] ?></td>
          <td align="center"><?= $dta['bulan'] ?></td>
          <td align="center"><?= format_rupiah($dta['jumlah']) ?></td>
          <td align="center"><?= $dta['ket'] ?></td>
        </tr>
        <?php $i++; ?>
        <?php $total += $dta['jumlah']; ?>
      <?php endwhile ?>
      <tr>
        <td colspan="6" align="right"><b>Total</td>
        <td align="right"><b><?= format_rupiah($total) ?></b></td>
      </tr>
    </table>
    <table width="100%">
      <tr>
        <td></td>
        <td width="200px">
          <br>
          <p>Bandung , <?= tgl_indo(date('Y-m-d')); ?></p> <br>
          <br>
          <p>____________________</p>
          <p><?= $sw['nama_petugas'] ?></p>
        </td>
      </tr>
    </table>
  </body>

  </html>
<?php
} else {
  header("location: loginauth.php");
}
?>