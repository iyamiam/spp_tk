<?php
include 'koneksi.php';
include 'header.php';

if (isset($_GET['id_petugas'])) {
  $id = $_GET['id_petugas'];
  $query = "SELECT * FROM petugas WHERE id_petugas = '$id'";
  $exec = mysqli_query($conn, $query);
  $res = mysqli_fetch_assoc($exec);
}
if (isset($_POST['simpan'])) {
  $nama_petugas = htmlentities(strip_tags($_POST['nama_petugas']));
  $user_petugas = htmlentities(strip_tags($_POST['user_petugas']));
  $pass_petugas = htmlentities(strip_tags($_POST['pass_petugas']));
  $id_petugas = $_POST['id_petugas'];

  $query = "UPDATE petugas SET nama_petugas = '$nama_petugas', user_petugas = '$user_petugas', pass_petugas = '$pass_petugas' 
            WHERE id_petugas = '$id_petugas'";
  $exec = mysqli_query($conn, $query);
  if ($exec) {
    echo "<script>alert('data petugas berhasil diedit')
    document.location = 'index.php';
    </script>";
  } else {
    echo "<script>alert('data petugas gagal diedit')
    document.location = 'index.php';
    </script>";
  }
}
?>

<div class="row justify-content-center">
  <div class="col-xl-10 col-lg-12 col-md-9">
    <div class="card o-hidden border-0 shadow-lg my-5">
      <div class="card-body p-0">
        <!-- Nested Row within Card Body -->
        <div class="row">
          <div class="col-lg-6">
            <img src="img/tk.png" height="400px" style="margin-left: 150px; padding: 50px;" alt="">
          </div>
          <div class="col-lg-6">
            <div class="p-5">
              <div class="text-center">
                <h1 class="h4 text-gray-900 mb-4">Edit Data Petugas</h1>
              </div>
              <form class="user" method="POST" action="">
                <div class="form-group">
                  <input type="hidden" name="id_petugas" value="<?= $res['id_petugas'] ?>">
                  <input type="text" autocomplete="off" required name="nama_petugas" class="form-control form-control-user" id="exampleInputEmail" aria-describedby="emailHelp" placeholder="Masukkan nama petugas.." value="<?= $res['nama_petugas'] ?>">
                </div>
                <div class="form-group">
                  <input type="text" autocomplete="off" required name="user_petugas" class="form-control form-control-user" id="exampleInputEmail" aria-describedby="emailHelp" placeholder="Masukkan username petugas..." value="<?= $res['user_petugas'] ?>">
                </div>
                <div class="form-group">
                  <input type="password" autocomplete="off" required name="pass_petugas" class="form-control form-control-user" id="exampleInputPassword" placeholder="Password" value="<?= $res['pass_petugas'] ?>">
                </div>
                <button type="submit" name="simpan" class="btn btn-primary btn-user btn-block">
                  Simpan
                </button>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<?php
include 'footer.php'; ?>